#!/bin/sh
../../apache/bin/php wts.php
